import styled from 'styled-components/native';

export default styled.View`
  background-color: #7d40e7;
  width: 100%;
  height: 100%;
`;
