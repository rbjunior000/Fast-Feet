import React from 'react';
import {View, Text, StyleSheet} from 'react-native';

// import { Container } from './styles';

export default function StepProgress() {
  return (
    <View
      style={{
        alignItems: 'center',
        backgroundColor: '#444',
        justifyContent: 'center',
      }}>
      <View style={styles.stepProgressBar}>
        <View style={styles.step}>
          <View style={styles.bullet}>
            <Text>4</Text>
          </View>
          <Text style={styles.stepText}>About</Text>
        </View>
        <View style={styles.step}>
          <View style={styles.bullet}>
            <Text>4</Text>
          </View>
          <Text style={styles.stepText}>About</Text>
        </View>
        <View style={styles.step}>
          <View style={styles.bullet}>
            <Text>4</Text>
          </View>
          <Text style={styles.stepText}>About</Text>
        </View>
        <View style={styles.step}>
          <View style={styles.bullet}>
            <Text>4</Text>
          </View>
          <Text style={styles.stepText}>About</Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  stepProgressBar: {
    // backgroundColor: '#444',
    flexDirection: 'row',
    justifyContent: 'space-between',
    // alignItems: 'center',
    width: 300,
    marginHorizontal: 'auto',
    marginBottom: 40,
  },
  step: {
    textAlign: 'center',
  },
  stepText: {
    marginBottom: 10,
    color: '#28a745',
  },
  bullet: {
    borderStyle: 'solid',
    borderLeftWidth: 1,
    borderRightWidth: 1,
    borderTopWidth: 1,
    borderBottomWidth: 1,
    height: 20,
    width: 20,
    borderRadius: 20,
    color: '#28a745',
    position: 'relative',
    lineHeight: 20,
  },
});
