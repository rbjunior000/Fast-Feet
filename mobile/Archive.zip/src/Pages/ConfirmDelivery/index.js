/* eslint-disable react-native/no-inline-styles */
import React, {useState} from 'react';
import {View, StyleSheet, Text, TouchableOpacity} from 'react-native';
import {RNCamera} from 'react-native-camera';
// import { Container } from './styles';

export default function ConfirmDelivery() {
  const [camera, setCamera] = useState();

  const takePicture = async () => {
    if (camera) {
      const options = {quality: 0.5, base64: true};
      const data = await camera.takePictureAsync(options);
      console.log(data.uri);
    }
  };

  return (
    <>
      <RNCamera style={styles.preview} ref={ref => setCamera(ref)} />
      <View style={{flex: 0, flexDirection: 'row', justifyContent: 'center'}}>
        <TouchableOpacity onPress={takePicture} style={styles.capture}>
          <Text style={{fontSize: 14}}> SNAP </Text>
        </TouchableOpacity>
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  background: {
    height: 155,
    backgroundColor: '#7D40E7',
  },
  preview: {
    flex: 1,
    justifyContent: 'flex-end',
    alignItems: 'center',
  },
  title: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#999999',
  },
  content: {
    fontSize: 14,
    color: '#666666',
  },
  buttonsText: {
    fontSize: 12,
    color: '#999999',
    marginTop: 2,
  },
  input: {
    paddingHorizontal: 20,
  },
});

ConfirmDelivery.navigationOptions = {
  title: 'Confirmar entrega',
};
